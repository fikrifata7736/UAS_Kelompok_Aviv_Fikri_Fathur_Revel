<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function index()
    {
        $users = User::all();
        return view ('admin.dashboard')->with('users', $users);
    }


    public function create()
    {
      //
    }


    public function store(Request $request)
    {
       //
    }


    public function show($id)
    {
        $user = User::find($id);
        return view('admin.show')->with('users', $user);
    }


    public function edit($id)
    {
        $user = User::find($id);
        return view('admin.edit')->with('users', $user);
    }


    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $input = $request->all();
        $user->update($input);
        return redirect('user')->with('flash_message', 'student Updated!');
    }


    public function destroy($id)
    {
        User::destroy($id);
        return redirect('user')->with('flash_message', 'Student deleted!');
    }
}
