<?php $__env->startSection('content'); ?>


<div class="card">
  <div class="card-header">User Page</div>
  <div class="card-body">


        <div class="card-body">
        <h5 class="card-title">id : <?php echo e($users->id); ?></h5>
        <p class="card-text">name : <?php echo e($users->name); ?></p>
        <p class="card-text">email : <?php echo e($users->email); ?></p>
  </div>



  </div>
</div>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PenwebFikriFataFauzi\uas-pemweb-2022\uas-pemweb-2022\resources\views/admin/show.blade.php ENDPATH**/ ?>