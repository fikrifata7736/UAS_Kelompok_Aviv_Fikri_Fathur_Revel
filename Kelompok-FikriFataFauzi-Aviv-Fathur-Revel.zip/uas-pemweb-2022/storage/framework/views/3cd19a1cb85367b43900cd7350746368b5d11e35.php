<?php $__env->startSection('content'); ?>
    <h1>All Books
        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i></a>
</h1>
<?php if (! (count ($books))): ?>

<?php endif; ?>

<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
<div class="row">
    <?php if(count($books)): ?>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-2" style="margin-left: 20px; margin-top: 20px; padding: 10px; box-shadow: inset 0 -3em 3em rgba(0,0,0,0.1), 0 0  0 1px #fde2e4, 0.3em 0.3em 1em rgba(0,0,0,0.3);">
    <div class="card">
        <img src="<?php echo e($book->image); ?>" class="card-image-top">
        <div class="card-body">
            <h3><a href="<?php echo e(route('books.show', $book->id)); ?>"><?php echo e($book->title); ?></a></h3>
            <div class="text-danger">
                <?php for($i = 1; $i <= $book->rating_star; $i++): ?>
                <i class="fas fa-star"></i>
                <?php endfor; ?>
            </div>
            <p><?php echo e(Str::limit($book->description, 250)); ?></p>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PenwebFikriFataFauzi\uas-pemweb-2022\uas-pemweb-2022\resources\views/books/index.blade.php ENDPATH**/ ?>