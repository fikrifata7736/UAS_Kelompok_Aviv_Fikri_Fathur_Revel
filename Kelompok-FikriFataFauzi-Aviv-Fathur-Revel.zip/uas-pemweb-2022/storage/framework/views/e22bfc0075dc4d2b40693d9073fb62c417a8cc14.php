<?php $__env->startSection('content'); ?>

<div class="card">
  <div class="card-header">User Page Edit</div>
  <div class="card-body">

      <form action="<?php echo e(url('user/' .$users->id)); ?>" method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PATCH"); ?>
        <input type="hidden" name="id" id="id" value="<?php echo e($users->id); ?>" id="id" />
        <label>ID</label></br>
        <input type="text" name="id" id="name" value="<?php echo e($users->id); ?>" class="form-control"></br>
        <label>Name</label></br>
        <input type="text" name="name" id="address" value="<?php echo e($users->name); ?>" class="form-control"></br>
        <label>Email</label></br>
        <input type="text" name="email" id="mobile" value="<?php echo e($users->email); ?>" class="form-control"></br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PenwebFikriFataFauzi\uas-pemweb-2022\uas-pemweb-2022\resources\views/admin/edit.blade.php ENDPATH**/ ?>