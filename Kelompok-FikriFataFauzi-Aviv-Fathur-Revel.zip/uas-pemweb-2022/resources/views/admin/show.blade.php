@extends('layouts.admin-app')
@section('content')


<div class="card">
  <div class="card-header">User Page</div>
  <div class="card-body">


        <div class="card-body">
        <h5 class="card-title">id : {{ $users->id }}</h5>
        <p class="card-text">name : {{ $users->name }}</p>
        <p class="card-text">email : {{ $users->email }}</p>
  </div>



  </div>
</div>
