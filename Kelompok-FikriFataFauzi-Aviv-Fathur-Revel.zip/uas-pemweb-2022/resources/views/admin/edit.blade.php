@extends('layouts.admin-app')
@section('content')

<div class="card">
  <div class="card-header">User Page Edit</div>
  <div class="card-body">

      <form action="{{ url('user/' .$users->id) }}" method="post">
        {!! csrf_field() !!}
        @method("PATCH")
        <input type="hidden" name="id" id="id" value="{{$users->id}}" id="id" />
        <label>ID</label></br>
        <input type="text" name="id" id="name" value="{{$users->id}}" class="form-control"></br>
        <label>Name</label></br>
        <input type="text" name="name" id="address" value="{{$users->name}}" class="form-control"></br>
        <label>Email</label></br>
        <input type="text" name="email" id="mobile" value="{{$users->email}}" class="form-control"></br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>

  </div>
</div>

@stop
