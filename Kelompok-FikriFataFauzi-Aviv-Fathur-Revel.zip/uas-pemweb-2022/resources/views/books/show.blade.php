@extends('home')

@section('content')
<center> <div class="card mb-3" style="width: 25rem; border-radius: 20px;">
    <center><img src="{{ $book->image }}"class="card-image-top" style="width: 22rem "></center>
        <div class="card-body">
            <h1>{{ $book->title }}</h1>
            <div class="text-danger">
                @for ($i = 1; $i <= $book->rating_star; $i++)
                <i class="fas fa-star"></i>
                @endfor
            </div>
            <p>{{ $book->description }}</p>

            <h2>Comments</h2>
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><b>test123: </b>Film nya Horror</li>
                <form action="#" method="POST">
                    <button type="submit" class="btn btn-link text-danger"></button>
                </form>
            </li>
            </ul>
            <form action="#" method="POST">
                @csrf
                <input type="text" name="comment" class="btn btn-link text-danger">
                <button type="submit" class="btn btn-link text-danger">Delete</button>
            </form>

            <p>No comments</p>
            <form action="{{ route('books.comments.store', $book->id) }}" method="POST">
                @csrf
                <input type="text" name="comment" class="form-control" placeholder="say something..">
                <button type="submit" class="btn btn-primary mt-2 float-right">Comment</button>
            </form>
        </div>
        <div class="card-footer">
            <form action="#">
                <button type="submit" class="btn btn-link float-right">Delete</button>
            </form>
        </div>
    </div>
</center>
@endsection
