@extends('layouts.admin-app')

@section('content')
    <h1>All Books
        <a href="{{ route('books.create') }}" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i></a>
</h1>
@unless (count ($books))

@endunless

<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
  <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
<div class="row">
    @if (count($books))
        @foreach ($books as $book)
    <div class="col-md-2" style="margin-left: 20px; margin-top: 20px; padding: 10px; box-shadow: inset 0 -3em 3em rgba(0,0,0,0.1), 0 0  0 1px #fde2e4, 0.3em 0.3em 1em rgba(0,0,0,0.3);">
    <div class="card">
        <img src="{{ $book->image }}" class="card-image-top">
        <div class="card-body">
            <h3><a href="{{ route('books.show', $book->id) }}">{{ $book->title }}</a></h3>
            <div class="text-danger">
                @for ($i = 1; $i <= $book->rating_star; $i++)
                <i class="fas fa-star"></i>
                @endfor
            </div>
            <p>{{ Str::limit($book->description, 250) }}</p>
        </div>
    </div>
</div>
@endforeach
    @endif
</div>
@endsection
